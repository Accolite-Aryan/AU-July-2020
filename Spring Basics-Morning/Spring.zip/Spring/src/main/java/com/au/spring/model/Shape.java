package com.au.spring.model;

public interface Shape {
	public double area();
}
